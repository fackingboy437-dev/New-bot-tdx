const { configureWorkflow, restart_workflow } = await import('workflows');
await configureWorkflow({
  name: "Start Bot",
  command: "node index.js",
  base_directory: ".",
  tags: ["dev"]
});
await restart_workflow({ name: "Start Bot" });
